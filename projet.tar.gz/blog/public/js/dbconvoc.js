

$(document).ready(function(){

 $('#valider').click(function(){

 var datematch = $('#selectconvocation').val();

 var equipes = [];
 var listejoueurs = [];

 if($('#tdequipe').text() != ""){
   var equipe1 = $('#tdequipe').text();
   var col1 = [];
   $('.joueur td:nth-child(2) select').each(function(){
     if($(this).val() == "empty"){
       col1.push(0);
     }else{
       col1.push($(this).val());
     }
   });

   equipes.push(equipe1);
   listejoueurs.push(col1);
 }


 if($('#tdequipe-1').text() != ""){
   var equipe2 = $('#tdequipe-1').text();
   var col2 = [];
   $('.joueur td:nth-child(3) select').each(function(){
     if($(this).val() == "empty"){
       col2.push(0);
     }else{
       col2.push($(this).val());
     }
   });

   equipes.push(equipe2);
   listejoueurs.push(col2);
 }

 if($('#tdequipe-2').text() != ""){
   var equipe3 = $('#tdequipe-2').text();
   var col3 = [];
   $('.joueur td:nth-child(4) select').each(function(){
     if($(this).val() == "empty"){
       col3.push(0);
     }else{
       col3.push($(this).val());
     }
   });

   equipes.push(equipe3);
   listejoueurs.push(col3);
 }



    $.ajax({
    url:'/bdconvoc',
     method:'GET',
     data:{ datematch:datematch,
            equipes : equipes,
            listejoueurs : listejoueurs},
     dataType:'json',
     success:function(data)
     {
       alert("La convocation est bien enregistrée");

     },
       error: function(response) {
           console.log(response);
           alert("La convocation est bien enregistrée");
       }
   });


 }); // -- click valider

}); // -- document.ready
