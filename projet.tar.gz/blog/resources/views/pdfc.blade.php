 <!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
th {
color: white;
background-color:black;
}

</style>


<h2 align="center">CONVOCATION</h2>


<?php $date = date_create($val);?>
<h1 align="center">{{date_format($date,"d/m/Y")}}</h1>



<table >
<!--
   <tr>
    <th width='5%'> DATE </th>
    <td witdh ="15%"colspan="3">{{ $val }} </td>


   </tr>
!-->

<tbody >
  <tr>
       <th width="25%" >EQUIPE</th>
       <td width="25%" style="color:red">
         {{$equipe[0]}}
       </td>
        <td width="25%" style="color:red">
          {{$equipe[1]}}
          </td>
         <td width="25%" style="color:red">
           {{$equipe[2]}}
         </td>
  </tr>

  <tr>
    <th>COMPETITION</th>
    <td >{{ $compet[0]}}</td>
     <td >{{ $compet[1]}}</td>
         <td>{{ $compet[2]}}</td>
   </tr>
   <tr>
       <th>EQUIPE ADVERSE</th>
       <td >{{$adverse[0]}}</td>
        <td >{{$adverse[1]}}</td>
         <td>{{$adverse[2]}}</td>
   </tr>
   <tr>
    <th>SITES</th>
    <td >{{$site[0]}}</td>
     <td>{{$site[1]}}</td>
     <td >{{$site[2]}}</td>
  </tr>
  <tr>
    <th>TERRAIN</th>
    <td>{{$terrain[0]}}</td>
     <td>{{$terrain[1]}}</td>
     <td>{{$terrain[2]}}</td>
  </tr>
  <tr>
     <th>HEURE</th>
      <td>{{$heureformat[0]}}</td>
      <td>{{$heureformat[1]}}</td>
      <td>{{$heureformat[2]}}</td>
  </tr>
  <tr >
      <th align="right">Joueur 1</th>
      <td  id="td1" style='color:red'>{{$joueurs[0][0]}}</td>
       <td id="td1-1" style='color:red'>{{$joueurs[1][0]}}</td>
         <td id="td1-2" style='color:red'>{{$joueurs[2][0]}}</td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 2</th>

      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][1]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 3</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][2]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 4</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][3]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 5</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][4]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 6</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][5]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 7</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][6]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 8</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][7]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 9</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][8]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 10</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][9]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 11</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][10]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Remplaçant 1</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][11]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Remplaçant 2</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][12]."</td>";
        ?>
  </tr>
  <tr class="joueur">
      <th align="right">Remplaçant 3</th>
      <?php for($i=0;$i<3;$i++)
         echo "<td  style='color:red'>".$joueurs[$i][13]."</td>";
        ?>
  </tr>

  <tr>
      <th>Responsable</th>
      <td  id="tdresponsable" class="tdconvoc">{{$responsable[0]}}</td>
       <td id="tdresponsable-1">{{$responsable[1]}}</td>
         <td id="tdresponsable-2">{{$responsable[2]}}</td>
  </tr>




 </table>
<br></br>




<!-- <table >
 <tr><th width="25%">ABSENTS</th>
  <td></td></tr>

 </table>


   <table >
 <tr><th width="25%">NON CONVOQUES</th>
 <td></td>
 </tr> </table> -->
