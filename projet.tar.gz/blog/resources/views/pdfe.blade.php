<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>PDF logistique</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
th {
  background-color: black;
  color: white;
  border: 1px solid #dddddd;
  text-align: left;
 
}
td {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;

}
thead{
background:black;
}

</style>
</head>
<body>
<table>
 <caption>EFFECTIF</caption>
<thead >

<tr>
<th > 	Nom</th>
    <th> Prenom</th>
    <th >Catégorie</th>
    <th>Date de naissance</th>


</tr>
</thead>
<tbody>


@foreach($ab as $abs)
<tr>
   <td>{{ $abs->Nom }}</td>
   <td >{{ $abs->Prenom }}</td>
   <td>{{ $categories->find($abs->IDCategorie)->NomCategorie }}</td>
   <td>{{ $abs->date_naissance }}</td>
  </tr>
@endforeach



</tbody>
</table>

</body>
</html> 



