@extends('layouts')

@section('title','Absence')

@section('contenu')

<table width="800px" id="tab">
  <tr id="tab">
    <th>Nom</th>
    <th>Prenom</th>
    <th>Date</th>
    <th>Motif</th>
  </tr>



 <?php// foreach ( $absences as $absence): ?>
  <tr id="tab">
   <td>{{ $absences->DateAbsence}}</td>
   <td>{{ }}</td>
   <td>{{ }}</td>
   <td>{{]}</td>
  </tr>
 <?php //endforeach; ?>


@endsection
