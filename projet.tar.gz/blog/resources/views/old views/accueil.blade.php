@extends('layouts.app')


@section('content')

<div id="contenu" style="padding-left : 200px;padding-top : 50px">
<h1>Bonjour vous êtes à l'accueil</h1>
</div>

@endsection
