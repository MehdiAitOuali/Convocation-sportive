
@extends('layouts.app')

@section('content')
<div>
<h2>
   Nous avons bien recu vos informations: {{$rqst['nom']}}
    {{$rqst['date']}} {{ $rqst['motif'] }}
</h2>
</div>
 @endsection
