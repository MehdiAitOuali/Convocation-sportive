<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sportify template project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/bootstrap-4.1.2/bootstrap.min.css')); ?>">
<link href="<?php echo e(asset('plugins/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/OwlCarousel2-2.3.4/owl.carousel.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/OwlCarousel2-2.3.4/owl.theme.default.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/OwlCarousel2-2.3.4/animate.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/responsive.css')); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<style type="text/css">

  .dropdown-menu {
  	background-color: #03224C;
  }
  .motif{
    font-size: 12px !important;
    font-weight: bold !important;
    color : black
}


</style>



</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
		<div class="header_wrap d-flex flex-row align-items-center justify-content-center">

			<!-- Logo -->
		<div class="logo"><a href="/convocation"><img src="images/fff.svg" alt=""
																			height="13%" width="13%" ></a></div>

			<!-- Main Nav -->
			<nav class="main_nav">
				<ul class="d-flex flex-row align-items-center justify-content-center">
          <li class="active" style="margin-left : 50%"><a href="/convocation"> Home </a></li>
					<li><a href="/effectif">L'EFFECTIF</a></li>
					<li><a href="/absence">Absence</a></li>
          <li><a href="logistique">Logistique</a></li>
	<?php if (auth::check()): ?>
    				<li class="nav-item dropdown">
					        <a class="nav-link dropdown-toggle" href="/" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					          ESPACE ADMIN
					        </a>
					        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
					          <a class="dropdown-item" href="#">Action</a>
					          <a class="dropdown-item" href="#">Another action</a>
					          <a class="dropdown-item" href="#">Something else here</a>
					        </div>
					</li>
<?php endif ?>
          <!-- Authentication Links -->
          <?php if(auth()->guard()->guest()): ?>
              <li class="nav-item" style="padding-left : 20%">
                  <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
              </li>
              <?php if(Route::has('register')): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                  </li>
              <?php endif; ?>
          <?php else: ?>
              <li class="nav-item dropdown" style="padding-left : 20%">
                  <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                      <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                  </a>

                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item"  href="<?php echo e(route('logout')); ?>"
                         onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                          <?php echo e(__('Logout')); ?>

                      </a>

                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                      </form>
                  </div>
              </li>
          <?php endif; ?>
				</ul>

			</nav>

			<!-- Social -->
	<!--		<div class="social header_social">
				<ul class="d-flex flex-row align-items-center justify-content-start">
					<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-behance" aria-hidden="true"></i></a></li>
				</ul>
			</div>
-->
			<!-- Hamburger -->
			<div class="hamburger ml-auto"><i class="fa fa-bars" aria-hidden="true"></i></div>
		</div>

	</header>

	<!-- Fixed Header -->

	<header class="fixed_header">
		<div class="header_wrap d-flex flex-row align-items-center justify-content-center">

			<!-- Logo -->
			<div class="logo"><a href="/convocation"><img src="images/fff.svg" alt=""
																				height="10%" width="10%"></a></div>

			<!-- Main Nav -->
			<nav class="main_nav">
				<ul class="d-flex flex-row align-items-center justify-content-center">
					<li class="active" style="margin-left : 50%"><a href="/convocation">Home</a></li>
					<li><a href="effectif">L'EFFECTIF</a></li>
					<li><a href="absence">ABSENCE</a></li>
          <li><a href="logistique">Logistique</a></li>
        <?php if (auth::check()): ?>  <li class="nav-item dropdown" width="100%">
                  <a class="nav-link dropdown-toggle" href="/" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                ESPACE ADMIN
                  </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                  </div>
          </li><?php endif; ?>

          <!-- Authentication Links -->
          <?php if(auth()->guard()->guest()): ?>
              <li class="nav-item" style="padding-left : 20%">
                  <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
              </li>
              <?php if(Route::has('register')): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                  </li>
              <?php endif; ?>
          <?php else: ?>
              <li class="nav-item dropdown" style="padding-left : 20%">
                  <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                      <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                  </a>

                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item"  href="<?php echo e(route('logout')); ?>"
                         onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                          <?php echo e(__('Logout')); ?>

                      </a>

                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                      </form>
                  </div>
              </li>
          <?php endif; ?>
				</ul>
			</nav>

			<!-- Social
			<div class="social header_social">
				<ul class="d-flex flex-row align-items-center justify-content-start">
					<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-behance" aria-hidden="true"></i></a></li>
				</ul>
			</div>

			<!-- Hamburger -->
			<div class="hamburger ml-auto"><i class="fa fa-bars" aria-hidden="true"></i></div>

		</div>
	</header>

	<!-- Menu -->

	<div class="menu">
		<div class="menu_door door_left"></div>
		<div class="menu_door door_right"></div>
		<div class="menu_content d-flex flex-column align-items-center justify-content-center">
			<div class="menu_close">close</div>
			<div class="menu_nav_container">
				<nav class="menu_nav text-center">
					<ul>
						<li><a href="/convocation">home</a></li>
						<li><a href="effectif">l'effectif</a></li>
						<li><a href="absence">absence</a></li>
            <li><a href="logistique">Logistique</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>


<div class="home" style="height : 500px">
		<div class="background_image" style="background-image:url(images/ballon.jpg);"></div>
</div>

	<!-- About -->

  <?php echo $__env->yieldContent('content'); ?>

	<!-- Footer -->

	<footer class="footer">
   </footer>


</div>


<script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('styles/bootstrap-4.1.2/popper.js')); ?>"></script>
<script src="<?php echo e(asset('styles/bootstrap-4.1.2/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/greensock/TweenMax.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/greensock/TimelineMax.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/scrollmagic/ScrollMagic.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/greensock/animation.gsap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/greensock/ScrollToPlugin.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/OwlCarousel2-2.3.4/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/easing/easing.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/progressbar/progressbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/parallax-js-master/parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>


</body>
</html>
