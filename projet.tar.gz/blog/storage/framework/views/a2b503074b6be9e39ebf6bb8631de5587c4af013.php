		

<?php $__env->startSection('content'); ?>
<link href="vendor/select2/dist/css/select2.min.css" rel="stylesheet" />
<script src="vendor/select2/dist/js/select2.min.js"></script>
<link href="path/to/select2.min.css" rel="stylesheet" />
<script src="path/to/select2.min.js"></script>

	<div class="container"
	     style="padding-top : 5%;padding-bottom : 5%; max-width=1250px !important" >
	
		<div class="row justify-content-md-center" style="padding-bottom : 2%">
			<div class="col-md-6">
		
	    <select id="selectlog"  class="custom-select mr-sm-2">
					<?php for($i=0;$i<count($matchs);$i=$i+7){
	
							echo "<option value='$i'>";
								echo "Du ".$matchs[$i]->Date." au ".$matchs[$i+6]->Date."";
							?></option><?php
					}
					?>
			  </select>
			</div>
			
			<div class="col-md-2">
		<a href="<?php echo e('/logistique-pdf'); ?>" class ="fa fa-file-pdf-o" style="color:black"> Convert into pdf</a>
	 
			</div>
		</div>
	
	
	  <div class="row">
		 <div class="col-md-12">
	      <table class="table   table-bordered" id="tablog" >
	
	      </table>
	   </div>
	 </div>
	
	</div>
	
	<script>
	
	$(document).ready(function(){
	
	  changedate(0);
	
	  function changedate(val){
	
	    $.ajax({
	     url:"/lire",
	      method:'GET',
	      data:{ val:val },
	      dataType:'json',
	      success:function(data)
	      {
	        $('#tablog').html(data.table_data);
	      },
	        error: function(response) {
	            console.log(response);
	        }
	    });
	  }
	
	  $("#selectlog").change(function(){
			 var valeur = $("#selectlog").val();
	         changedate(valeur);
		});
	
	
	}
	);
	
	</script>
	
});
	
<?php $__env->stopSection(); ?>



	
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lbrah\blog1\resources\views/logistique.blade.php ENDPATH**/ ?>