 <!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>PDF absence</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

th {
  background-color: black;
  color: white;
  border: 1px solid #dddddd;
  text-align: left;
 
}
td {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;

}
thead{
background:black;
}


</style>
</head>
<body>
<table>
 <caption>LES ABSENCES</caption>
<thead>

<tr>
<th>Nom</th>
<th>Date</th>
<th>Motif</th>



</tr>
</thead>
<tbody>

<?php $__currentLoopData = $ab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<?php $__currentLoopData = $effectifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $effectif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($effectif->id==$abs->IDEffectif): ?>
<td><?php echo e($effectif->Nom); ?> <?php echo e($effectif->Prenom); ?></td>
<?php endif; ?> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<td><?php echo e($abs->DateAbsence); ?></td>
<td><?php echo e($abs->Motif); ?></td>
</tr>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</tbody>
</table>

</body>
</html> <?php /**PATH C:\Users\lbrah\blog1\resources\views/pdf.blade.php ENDPATH**/ ?>