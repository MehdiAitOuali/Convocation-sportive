<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
th {
color: white;
background-color:black;
}

</style>

<h2>CONVOCATIONS</h2>

    
   


<table >

   <tr>
    <th > DATE </th>
    <td colspan="3">
      
    </td>

   </tr>


<tbody >
  <tr>
       <th width="25%" >EQUIPE</th>
       <td width="25%"></td>
        <td width="25%"></td>
         <tdwidth="25%"></td>
  </tr>

  <tr>
    <th>COMPETITION</th>
    <td ></td>
     <td ></td>
         <td></td>
   </tr>
   <tr>
       <th>EQUIPE ADVERSE</th>
       <td ></td>
        <td ></td>
         <td></td>
   </tr>
   <tr>
    <th>SITES</th>
    <td ></td>
     <td></td>
         <td ></td>
  </tr>
  <tr>
    <th>TERRAIN</th>
    <td></td>
     <td ></td>
         <td ></td>
  </tr>
  <tr>
     <th>HEURE</th>
     <td  ></td>
      <td ></td>
         <td ></td>
  </tr>
  <tr >
      <th align="right">Joueur 1</th>
      <td  id="td1"></td>
       <td id="td1-1"></td>
         <td id="td1-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 2</th>
      <td id="td2"></td>
       <td id="td2-1"></td>
         <td id="td2-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 3</th>
      <td  id="td3"></td>
       <td id="td3-1"></td>
         <td id="td3-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 4</th>
      <td id="td4"></td>
       <td id="td4-1"></td>
         <td id="td4-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 5</th>
      <td id="td5"></td>
       <td id="td5-1"></td>
         <td id="td5-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 6</th>
      <td id="td6"></td>
       <td id="td6-1"></td>
         <td id="td6-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 7</th>
      <td id="td7"></td>
       <td id="td7-1"></td>
         <td id="td7-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 8</th>
      <td id="td8"></td>
       <td id="td8-1"></td>
         <td id="td8-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 9</th>
      <td  id="td9"></td>
       <td id="td9-1"></td>
         <td id="td9-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 10</th>
      <td  id="td10"></td>
       <td id="td10-1"></td>
         <td id="td10-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 11</th>
      <td  id="td11"></td>
       <td id="td11-1"></td>
         <td id="td11-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Remplaçant 1</th>
      <td  id="td12"></td>
       <td id="td12-1"></td>
         <td id="td12-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Remplaçant 2</th>
      <td  id="td13"></td>
       <td id="td13-1"></td>
         <td id="td13-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Remplaçant 3</th>
      <td  id="td14"></td>
       <td id="td14-1"></td>
         <td id="td14-2"></td>
  </tr>

  <tr>
      <th>Responsable</th>
      <td  id="tdresponsable" class="tdconvoc"></td>
       <td id="tdresponsable-1"></td>
         <td id="tdresponsable-2"></td>
  </tr>

  


 </table>



<?php /**PATH C:\Users\lbrah\blog1\resources\views/pdfc.blade.php ENDPATH**/ ?>