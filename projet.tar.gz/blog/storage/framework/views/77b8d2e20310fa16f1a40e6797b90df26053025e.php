<?php $__env->startSection('content'); ?>

<style>

  #tabconvocation > td { font-weight: bold;}
  .btn-success {
    width: 15%;
    margin-left: 27%;
    margin-bottom: 5%;
  }
  .effectif {
    color: red;
    font-size: 16px;
  }

</style>


   <div class="container" >
       <div class="row" style="margin : 2%;margin-left : 30%">
      <h2>CONVOCATIONS</h2>
    </div>
    <div class="row">

 <div class="col-xs-12 col-sm-6 col-md-8">



<table class="table  table-bordered table-striped table-sm  table-hover"
     style="background-color:white">
<thead class="thead-dark">
   <tr>
    <th> DATE </th>
    <td colspan="3">
      <select  id="selectconvocation" class="custom-select mr-sm-2">
  			<?php foreach ($matchs as $match): ?>
           <option  value="<?php echo e($match->Date); ?>"> <?php echo e($match->Date); ?>

           </option>
        <?php endforeach; ?>
  		</select>
    </td>

   </tr>
</thead>

<tbody class="thead-dark" id="tabconvocation">
  <tr>
       <th width="25%">EQUIPE</th>
       <td width="25%" id="tdequipe"></td>
        <td width="25%" id="tdequipe-1" ></td>
         <td width="25%"id="tdequipe-2"></td>
  </tr>

  <tr>
    <th>COMPETITION</th>
    <td  id="tdcompetition" class="tdconvoc"></td>
     <td id="tdcompetition-1"></td>
         <td id="tdcompetition-2"></td>
   </tr>
   <tr>
       <th>EQUIPE ADVERSE</th>
       <td  id="tdadverse" class="tdconvoc"></td>
        <td id="tdadverse-1"></td>
         <td id="tdadverse-2"></td>
   </tr>
   <tr>
    <th>SITES</th>
    <td  id="tdsite" class="tdconvoc"></td>
     <td id="tdsite-1"></td>
         <td id="tdsite-2"></td>
  </tr>
  <tr>
    <th>TERRAIN</th>
    <td id="tdterrain" class="tdconvoc"></td>
     <td id="tdterrain-1"></td>
         <td id="tdterrain-2"></td>
  </tr>
  <tr>
     <th>HEURE</th>
     <td  id="tdheure" class="tdconvoc"></td>
      <td id="tdheure-1"></td>
         <td id="tdheure-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 1</th>
      <td  id="td1"></td>
       <td id="td1-1"></td>
         <td id="td1-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 2</th>
      <td id="td2"></td>
       <td id="td2-1"></td>
         <td id="td2-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 3</th>
      <td  id="td3"></td>
       <td id="td3-1"></td>
         <td id="td3-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 4</th>
      <td id="td4"></td>
       <td id="td4-1"></td>
         <td id="td4-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 5</th>
      <td id="td5"></td>
       <td id="td5-1"></td>
         <td id="td5-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 6</th>
      <td id="td6"></td>
       <td id="td6-1"></td>
         <td id="td6-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 7</th>
      <td id="td7"></td>
       <td id="td7-1"></td>
         <td id="td7-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 8</th>
      <td id="td8"></td>
       <td id="td8-1"></td>
         <td id="td8-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 9</th>
      <td  id="td9"></td>
       <td id="td9-1"></td>
         <td id="td9-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 10</th>
      <td  id="td10"></td>
       <td id="td10-1"></td>
         <td id="td10-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Joueur 11</th>
      <td  id="td11"></td>
       <td id="td11-1"></td>
         <td id="td11-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Remplaçant 1</th>
      <td  id="td12"></td>
       <td id="td12-1"></td>
         <td id="td12-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Remplaçant 2</th>
      <td  id="td13"></td>
       <td id="td13-1"></td>
         <td id="td13-2"></td>
  </tr>
  <tr class="joueur">
      <th align="right">Remplaçant 3</th>
      <td  id="td14"></td>
       <td id="td14-1"></td>
         <td id="td14-2"></td>
  </tr>

  <tr>
      <th>Responsable</th>
      <td  id="tdresponsable" class="tdconvoc"></td>
       <td id="tdresponsable-1"></td>
         <td id="tdresponsable-2"></td>
  </tr>

  <tr>
    <th rowspan="3" ><div style="margin-top : 17%">
                        LOGISTIQUE</div></th>
      <td> VOITURES :kayna <br> kayna  </td>
      <td> VOITURES : </td>
      <td> VOITURES : </td>

  <tr> <td>BUVETTES : </td>
       <td>BUVETTES : </td>
       <td>BUVETTES : </td>
  </tr>
  <tr>  <td>MAILLOTS : </td>
        <td>MAILLOTS : </td>
        <td>MAILLOTS : </td>
  </tr>

   </tr>


  </tbody>
<!--

<tr>
    <th>DIRIGEANTS</th>
    <td><input type="text"></td>
  </tr>

<tr>
    <th>ARBITRE</th>
    <td><input type="text"></td>
  </tr>

-->

 </table>
</div>


<!-- Tableau pour absence et les non convoques -->




<div class="col-xs-6 col-md-2">


 <table class="table  table-bordered table-striped table-sm  table-hover"
    style="background-color:white">
    <thead class='thead-dark'>
      <tr>
        <th>NON CONVOQUES</th>
      </tr>
    </thead>
    <tbody id='bodynonconvoc'></tbody>
  </table>

</div>



<div class="col-xs-6 col-md-2">
	<table class="table  table-bordered table-striped table-sm  table-hover" style="background-color:white"
          >
          <thead class='thead-dark'>
           <tr>
              <th>ABSENTS</th>
            </tr>
          </thead>
          <tbody id='bodyabsence'></tbody>
 </table>
</div>

</div>

<div class="row">
<div class="col-lg-12">
<button type="button"
        id="valider" class="btn btn-success">Valider</button>
</div>
</div>

</div>

<div id="script"></div>

<div id="script2"></div>

<script>

$(document).ready(function(){


$("#tabconvocation").css({"font-weight":"bold",
                          "color":"black"});
$("#tdequipe").css("color","red");
$("#tdequipe-1").css("color","red");
$("#tdequipe-2").css("color","red");



  var valeur = $("#selectconvocation").val();
  changeselect(valeur);

  $("#selectconvocation").change(function(){
		 var valeur = $("#selectconvocation").val();
         changeselect(valeur);
	});

  function changeselect(val){
    $.ajax({
     url:"/readconvocation",
      method:'GET',
      data:{ val:val },
      dataType:'json',
      success:function(data)
      {

        $('#tdequipe').html(data[0].equipe);
        $('#tdequipe-1').html(data[1].equipe);
        $('#tdequipe-2').html(data[2].equipe);

        $('#tdcompetition').html(data[0].compet);
        $('#tdcompetition-1').html(data[1].compet);
        $('#tdcompetition-2').html(data[2].compet);

        $('#tdadverse').html(data[0].adverse);
        $('#tdadverse-1').html(data[1].adverse);
        $('#tdadverse-2').html(data[2].adverse);

        $('#tdsite').html(data[0].site);
        $('#tdsite-1').html(data[1].site);
        $('#tdsite-2').html(data[2].site);

        $('#tdterrain').html(data[0].terrain);
        $('#tdterrain-1').html(data[1].terrain);
        $('#tdterrain-2').html(data[2].terrain);

        $('#tdheure').html(data[0].heure);
        $('#tdheure-1').html(data[1].heure);
        $('#tdheure-2').html(data[2].heure);

$('#td1').html(data[0].j1[0]); $('#td1-1').html(data[1].j1[0]); $('#td1-2').html(data[2].j1[0]);
$('#td2').html(data[0].j2[1]); $('#td2-1').html(data[1].j2[1]); $('#td2-2').html(data[2].j2[1]);
$('#td3').html(data[0].j3[2]); $('#td3-1').html(data[1].j3[2]); $('#td3-2').html(data[2].j3[2]);
$('#td4').html(data[0].j4[3]); $('#td4-1').html(data[1].j4[3]); $('#td4-2').html(data[2].j4[3]);
$('#td5').html(data[0].j5[4]); $('#td5-1').html(data[1].j5[4]); $('#td5-2').html(data[2].j5[4]);
$('#td6').html(data[0].j6[5]); $('#td6-1').html(data[1].j6[5]); $('#td6-2').html(data[2].j6[5]);
$('#td7').html(data[0].j7[6]); $('#td7-1').html(data[1].j7[6]); $('#td7-2').html(data[2].j7[6]);
$('#td8').html(data[0].j8[7]); $('#td8-1').html(data[1].j8[7]); $('#td8-2').html(data[2].j8[7]);
$('#td9').html(data[0].j9[8]); $('#td9-1').html(data[1].j9[8]); $('#td9-2').html(data[2].j9[8]);
$('#td10').html(data[0].j10[9]); $('#td10-1').html(data[1].j10[9]);   $('#td10-2').html(data[2].j10[9]);
$('#td11').html(data[0].j11[10]); $('#td11-1').html(data[1].j11[10]); $('#td11-2').html(data[2].j11[10]);
$('#td12').html(data[0].j12[11]); $('#td12-1').html(data[1].j12[11]); $('#td12-2').html(data[2].j12[11]);
$('#td13').html(data[0].j13[12]); $('#td13-1').html(data[1].j13[12]); $('#td13-2').html(data[2].j13[12]);
$('#td14').html(data[0].j14[13]); $('#td14-1').html(data[1].j14[13]); $('#td14-2').html(data[2].j14[13]);

        $('#tdresponsable').html(data[0].responsable);
        $('#tdresponsable-1').html(data[1].responsable);
        $('#tdresponsable-2').html(data[2].responsable);

       $('#bodynonconvoc').html(data[0].nonconvoc);

        $('#bodyabsence').html(data[0].absence);

        $('#script').html(data[0].script);

      },
        error: function(response) {
            console.log(response);
        }
    });
  }

});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lbrah\blog1\resources\views/convocation.blade.php ENDPATH**/ ?>