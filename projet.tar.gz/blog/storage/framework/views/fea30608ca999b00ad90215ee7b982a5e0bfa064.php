<?php $__env->startSection('title','Effectif'); ?>

<?php $__env->startSection('content'); ?>

<div id="contenu" style="padding-left : 200px">

<table width="800px" id="tab">
  <tr id="tab">
    <th>Nom</th>
    <th>Prenom</th>
    <th>Catégorie</th>
    <th>Date de naissance</th>
  </tr>

 <?php foreach ( $effectifs as $effectif): ?>
  <tr id="tab">
   <td><?php echo e($effectif->Nom); ?></td>
   <td><?php echo e($effectif->Prenom); ?></td>
   <td><?php echo e($categories->find($effectif->IDCategorie)->NomCategorie); ?></td>
   <td><?php echo e($effectif->date_naissance); ?></td>
  </tr>
 <?php endforeach; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>