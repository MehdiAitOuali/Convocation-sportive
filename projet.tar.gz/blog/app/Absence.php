<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Absence extends Model
{
  protected $table = 'ABSENCE';

  protected $fillable = [
      'IDEffectif', 'DateAbsence','Motif'
  ];

 public $timestamps = false;

 public function effectifs()
  {
      return $this->hasMany(Effectif::class);
  }

}
