<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Arbitrage extends Model
{
  protected $table = 'ARBITRAGE';

  protected $fillable = [
      'IDMatch', 'ArbitreCentre','ArbitreTouche1',
      'ArbitreTouche2','Dirigeant'
  ];

 public $timestamps = false;
}
