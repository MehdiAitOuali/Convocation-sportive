<?php

namespace App\Http\Controllers;

use App\Convocation;
use App\Effectif;
use App\Match;
use App\Absence;
use App\Arbitrage;
use App\Logistique;
use App\Equipe;
use DB;
use PDF;
use Dompdf\Dompdf;

use Illuminate\Http\Request;


class ConvocationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

      $effectifs =  Effectif::all();
      $matchs =  Match::select('Date')->distinct()->get();

      return view('convocation',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs]);

    }


  public function pdfc(Request $request){

       $val = $request->get('date');

       $matchs =  Match::where('Date',$val)
                           ->get();

         for($i=0;$i<count($matchs);$i++){

         $equipe[] = Equipe::find($matchs[$i]->IDEquipe)->NomEquipe;
         $compet[] = Match::where('Date',$val)
                          ->where('IDEquipe',$matchs[$i]->IDEquipe)
                          ->value('Competition');
         $adverse[]= Match::where('Date',$val)
                         ->where('IDEquipe',$matchs[$i]->IDEquipe)
                         ->value('EquipeAdverse');
         $site []  = Match::where('Date',$val)
                         ->where('IDEquipe',$matchs[$i]->IDEquipe)
                         ->value('site');

       $terrain [] = Match::where('Date',$val)
                     ->where('IDEquipe',$matchs[$i]->IDEquipe)
                     ->value('Terrain');

       $responsable[] = Equipe::find($matchs[$i]->IDEquipe)
                              ->Responsable;;

       $heure[]= Match::where('Date',$val)
                       ->where('IDEquipe',$matchs[$i]->IDEquipe)
                       ->value('Heure');

       $h[]= explode(':',$heure[$i]);
       $heureformat[] =$h[$i][0].'H'.$h[$i][1];

     }



     $joueursbd = ["Joueur1","Joueur2","Joueur3","Joueur4",
                   "Joueur5","Joueur6","Joueur7","Joueur8",
                   "Joueur9","Joueur10","Joueur11","Remplacant1",
                   "Remplacant2","Remplacant3"];

 for($i=0;$i<count($matchs);$i++){
   $categorieequipe = Equipe::find($matchs[$i]->IDEquipe)
                           ->IDCategorie;
   $effectifs = Effectif::where('IDCategorie',$categorieequipe)
                         ->get();

   $convocexiste = Convocation::where("IDMatch",$matchs[$i]->id)
                           ->get();
       foreach($joueursbd as $joueurbd){

        if($convocexiste != "[]"){

          $ideffectif = Convocation::where("IDMatch",$matchs[$i]->id)
                                   ->value($joueurbd);

          if($ideffectif != 0){
            $geteffectif = Effectif::find($ideffectif);
            $ch = $geteffectif->Nom." ".$geteffectif->Prenom;
          }else{
            $ch = "";
          }

        }else{
            $ch= "";
        }
         $jou[] =$ch;
      }
      $joueurs[]=$jou;
      $jou = [];
  }

     for($j=count($equipe);$j<=3;$j++){
        $equipe[$j]=""; $compet[$j]=""; $adverse[$j]="";
        $site[$j]="";   $terrain[$j]=""; $heureformat[$j]="";
        $responsable[$j]="";


        for($k=0;$k<15;$k++){
          $joueurs[$j][$k] ="";
       }

     }


    $pdf= PDF::loadView('pdfc',(compact('val','equipe','compet',
                                          'adverse','site','terrain',
                                          'responsable','heureformat','joueurs')));
   	$pdf->setPaper('a4','portrait');

    	return $pdf->stream();

}


  public function recupererpdf(Request $request){
    if($request->ajax()){

      $val= $request->get('val');

      $data= array('date' => $val);
      echo json_encode($data);
  }

}

    public function selectdate(request $request){
      if($request->ajax()){
        $val = $request->get('val');

        $matchs =  Match::where('Date',$val)
                            ->get();
      $joueursbd = ["Joueur1","Joueur2","Joueur3","Joueur4",
                                          "Joueur5","Joueur6","Joueur7","Joueur8",
                                          "Joueur9","Joueur10","Joueur11","Remplacant1",
                                          "Remplacant2","Remplacant3"];

          for($i=0;$i<count($matchs);$i++){

          $equipe[] = Equipe::find($matchs[$i]->IDEquipe)->NomEquipe;
          $compet[] = Match::where('Date',$val)
                           ->where('IDEquipe',$matchs[$i]->IDEquipe)
                           ->value('Competition');
          $adverse[]= Match::where('Date',$val)
                          ->where('IDEquipe',$matchs[$i]->IDEquipe)
                          ->value('EquipeAdverse');
          $site []  = Match::where('Date',$val)
                          ->where('IDEquipe',$matchs[$i]->IDEquipe)
                          ->value('site');

        $terrain [] = Match::where('Date',$val)
                      ->where('IDEquipe',$matchs[$i]->IDEquipe)
                      ->value('Terrain');

        $responsable[] = Equipe::find($matchs[$i]->IDEquipe)
                               ->Responsable;;

        $heure[]= Match::where('Date',$val)
                        ->where('IDEquipe',$matchs[$i]->IDEquipe)
                        ->value('Heure');

        $h[]= explode(':',$heure[$i]);
        $heureformat[] =$h[$i][0].'H'.$h[$i][1];


        $categorieequipe = Equipe::find($matchs[$i]->IDEquipe)
                                ->IDCategorie;
        $effectifs = Effectif::where('IDCategorie',$categorieequipe)
                              ->get();


     $convocexiste = Convocation::where("IDMatch",$matchs[$i]->id)
                                              ->get();
          foreach($joueursbd as $joueurbd){


           if($convocexiste != "[]"){

             $ideffectif = Convocation::where("IDMatch",$matchs[$i]->id)
                                      ->value($joueurbd);

             if($ideffectif != 0){
             $geteffectif = Effectif::find($ideffectif);

                  if(\Auth::check()){
                     $selectval = "selectj";
                        $ch ="<select name='carlist' form='carform'
                          class='$selectval form-control'>
                          <option value='".$geteffectif->id."' selected>
                          ".$geteffectif->Nom." ".$geteffectif->Prenom."
                          </option>
                          <option value='empty' ><-- Effacer --></option>
                          </select>";
                    }else{
                      $ch = "<div class='effectif'>".$geteffectif->Nom." ".$geteffectif->Prenom."</div>";
                    }
              }else{
                if(\Auth::check()){
              $selectval = "selectj";
                $ch ="<select name='carlist' form='carform'
                    class='$selectval form-control'>
                    <option value='empty' ></option>";
                foreach ($effectifs as $effectif) {
                  $ideffecabsent = Absence::where('DateAbsence',$val)
                                     ->where('IDEffectif',$effectif->id)
                                     ->get();
                   $effecconvoques = "[]";
                  foreach($joueursbd as $joueurbd){

                        for($j=0;$j<count($matchs) && $effecconvoques == "[]" ;$j++)
                          $effecconvoques = Convocation::where("IDMatch",$matchs[$j]->id)
                                        ->where($joueurbd,$effectif->id)
                                        ->get();
                   }

                  if($ideffecabsent == "[]" && $effecconvoques == "[]"){
                      $ch .= "<option value='".
                           $effectif->id."'>
                       ".$effectif->Nom." ".$effectif->Prenom."
                        </option>";
                  }
                }

            $ch .= "</select>";

              } else $ch = "";
            }

           } else{
             if(\Auth::check()){
            $selectval = "selectj";
              $ch ="<select name='carlist' form='carform'
                  class='$selectval form-control'>
                  <option value='empty' ></option>";
           foreach ($effectifs as $effectif) {
           $ideffecabsent = Absence::where('DateAbsence',$val)
                                   ->where('IDEffectif',$effectif->id)
                                   ->get();
                                   $effecconvoques = "[]";
                                  foreach($joueursbd as $joueurbd){
                                      for($j=0;$j<count($matchs) && $effecconvoques == "[]";$j++)

                                     $effecconvoques = Convocation::where("IDMatch",$matchs[$j]->id)
                                                                  ->where($joueurbd,$effectif->id)
                                                                  ->get();
                                   }

             if($ideffecabsent == "[]" &&  $effecconvoques == "[]"){
               $ch .= "<option value='".
                         $effectif->id."'>
                     ".$effectif->Nom." ".$effectif->Prenom."
                      </option>";
             }
           }

          $ch .= "</select>";
        } else $ch="";
        }
         $select[]= $ch;
        }

        $j1[] = $select;  $j2[] = $select; $j3[] = $select;
        $j4[] = $select;  $j5[] = $select; $j6[] = $select;
        $j7[] = $select;  $j8[] = $select; $j9[] = $select;
        $j10[] = $select; $j11[] = $select;$j12[] = $select;
        $j13[] = $select; $j14[] = $select;

        $select = [];

      }


        $nonconvoc ="";
        foreach ($effectifs as $effectif) {
          $ideffecabsent = Absence::where('DateAbsence',$val)
                                  ->where('IDEffectif',$effectif->id)
                                  ->get();

         $matchs =  Match::where('Date',$val)
                          ->get();


         $effecconvoques = "[]";
          for($i=0;$i<count($matchs);$i++){
            if($effecconvoques == "[]" ){
               foreach($joueursbd as $joueurbd){
                  if($effecconvoques == "[]" )
                    $effecconvoques = Convocation::where("IDMatch",$matchs[$i]->id)
                                                 ->where($joueurbd,$effectif->id)
                                                 ->get();
                  }
               }
           }

          if($ideffecabsent == "[]" && $effecconvoques == "[]"){
            $nonconvoc .="<tr>
                          <td id='".$effectif->id."'>
                            ".$effectif->Nom." ".
                              $effectif->Prenom."
                          </td>
                        </tr>";
          }
        }
        $absence ="";
        foreach ($effectifs as $effectif) {
          $ideffecabsent = Absence::where('DateAbsence',$val)
                                  ->where('IDEffectif',$effectif->id)
                                  ->get();

          if($ideffecabsent != "[]"){
          $absence .="<tr>
                          <td>
                            ".$effectif->Nom." ".
                              $effectif->Prenom."
                          </td>
                        </tr>";
          }
        }

         $script = "<script src=".asset('js/convocation.js').">
                      </script>";

    for($j=count($equipe);$j<=3;$j++){
       $equipe[$j]=""; $compet[$j]=""; $adverse[$j]="";
       $site[$j]="";   $terrain[$j]=""; $heureformat[$j]="";
       $responsable[$j]="";

        for($k=0;$k<15;$k++){
         $j1[$j][$k]=""; $j2[$j][$k]="";$j3[$j][$k]="";
         $j4[$j][$k]=""; $j5[$j][$k]="";$j6[$j][$k]="";
         $j7[$j][$k]=""; $j8[$j][$k]="";$j9[$j][$k]="";
         $j10[$j][$k]=""; $j11[$j][$k]="";$j12[$j][$k]="";
         $j13[$j][$k]=""; $j14[$j][$k]="";
       }
    }

  for($i=0;$i<count($equipe);$i++){
        $data[] = array('equipe' => $equipe[$i],
                      'compet' => $compet[$i],
                      'adverse'=> $adverse[$i],
                      'site'   => $site[$i],
                      'terrain'=> $terrain[$i],
                      'heure'  => $heureformat[$i],
        'j1' => $j1[$i],  'j2'=> $j2[$i],  'j3'=> $j3[$i],
        'j4' => $j4[$i],  'j5'=> $j5[$i],  'j6'=> $j6[$i],
        'j7' => $j7[$i],  'j8'=> $j8[$i],  'j9'=> $j9[$i],
        'j10'=> $j10[$i],'j11'=> $j11[$i],'j12'=> $j12[$i],
        'j13'=> $j13[$i],'j14'=> $j14[$i],
                   'responsable'  => $responsable[$i],
                   'nonconvoc'    => $nonconvoc,
                   'absence'      => $absence,
                  'script'       => $script);
        }

        echo json_encode($data);
  }
}

    public function convoquer(Request $request)
    {
      if($request->ajax()){
        $convoques = $request->get('convoques');
        $nonconvoques = $request->get('nonconvoques');
        $date = $request->get('date');

        $matchs =  Match::where('Date',$date)
                            ->get();
        $categorieequipe = Equipe::find($matchs[0]->IDEquipe)
                                  ->IDCategorie;
        $effectifs = Effectif::where('IDCategorie',$categorieequipe)
                                  ->get();

        $option = "<option value='empty'></option>";
        foreach ($effectifs as $effectif) {
          $ideffecabsent = Absence::where('DateAbsence',$date)
                         ->where('IDEffectif',$effectif->id)
                         ->get();
          if($ideffecabsent == "[]" &&
             in_array($effectif->id,$nonconvoques)){
             $option .= "<option value='".
                      $effectif->id."'>
                      ".$effectif->Nom." ".$effectif->Prenom."
                     </option>";
          }
        }

        $nonconvoc ="";
        foreach ($effectifs as $effectif) {
          $ideffecabsent = Absence::where('DateAbsence',$date)
                                  ->where('IDEffectif',$effectif->id)
                                  ->get();
          if($ideffecabsent == "[]" &&
             in_array($effectif->id,$nonconvoques))
            $nonconvoc .="<tr>
                          <td id='".$effectif->id."'>
                            ".$effectif->Nom." ".
                              $effectif->Prenom."
                          </td>
                        </tr>";

        }


        $script = "<script src=".asset('js/dbconvoc.js').">
                     </script>";


        $data= array('option' => $option,
                      'nonconvoc' => $nonconvoc,
                      'script' => $script);
        echo json_encode($data);
      }
    }


 public function bdconvoc(Request $request)
    {
      if($request->ajax()){
        $datematch = $request->get('datematch');
        $equipes = $request->get('equipes');
        $listejoueurs = $request->get('listejoueurs');

        $matchs =  Match::where('Date',$datematch)
                            ->get();

        for($i=0;$i<count($matchs);$i++){
          $idequipe = $matchs[$i]->IDEquipe;
          $idmatch = $matchs[$i]->id;

          $convocation = Convocation::where('IDMatch',$idmatch)
                                     ->count();

          if( $convocation == 0 ){
            Convocation::create([
               'IDMatch' => $idmatch,
               'Joueur1' => $listejoueurs[$i][0],
               'Joueur2' => $listejoueurs[$i][1],
               'Joueur3' => $listejoueurs[$i][2],
               'Joueur4' => $listejoueurs[$i][3],
               'Joueur5' => $listejoueurs[$i][4],
               'Joueur6' => $listejoueurs[$i][5],
               'Joueur7' => $listejoueurs[$i][6],
               'Joueur8' => $listejoueurs[$i][7],
               'Joueur9' => $listejoueurs[$i][8],
              'Joueur10' => $listejoueurs[$i][9],
              'Joueur11' => $listejoueurs[$i][10],
           'Remplacant1' => $listejoueurs[$i][11],
           'Remplacant2' => $listejoueurs[$i][12],
           'Remplacant3' => $listejoueurs[$i][13]
             ]);
          }else{
            Convocation::where('IDMatch',$idmatch)
                        ->update([
               'Joueur1' => $listejoueurs[$i][0],
               'Joueur2' => $listejoueurs[$i][1],
               'Joueur3' => $listejoueurs[$i][2],
               'Joueur4' => $listejoueurs[$i][3],
               'Joueur5' => $listejoueurs[$i][4],
               'Joueur6' => $listejoueurs[$i][5],
               'Joueur7' => $listejoueurs[$i][6],
               'Joueur8' => $listejoueurs[$i][7],
               'Joueur9' => $listejoueurs[$i][8],
              'Joueur10' => $listejoueurs[$i][9],
              'Joueur11' => $listejoueurs[$i][10],
           'Remplacant1' => $listejoueurs[$i][11],
           'Remplacant2' => $listejoueurs[$i][12],
           'Remplacant3' => $listejoueurs[$i][13]
             ]);

          }
        }

      }
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Convocation  $convocation
     * @return \Illuminate\Http\Response
     */
    public function show(Convocation $convocation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Convocation  $convocation
     * @return \Illuminate\Http\Response
     */
    public function edit(Convocation $convocation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Convocation  $convocation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Convocation $convocation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Convocation  $convocation
     * @return \Illuminate\Http\Response
     */
    public function destroy(Convocation $convocation)
    {
        //
    }
}
