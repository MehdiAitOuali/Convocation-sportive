<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Convocation extends Model
{
  protected $table = 'CONVOCATION';

  protected $fillable = [
      'IDMatch', 'Joueur1','Joueur2',
      'Joueur3', 'Joueur4','Joueur5',
      'Joueur6', 'Joueur7','Joueur8',
      'Joueur9', 'Joueur10','Joueur11',
      'Remplacant1', 'Remplacant2','Remplacant3',
      'Remplacant4','Remplacant5','IDArbitrage'     
  ];

 public $timestamps = false;

}
