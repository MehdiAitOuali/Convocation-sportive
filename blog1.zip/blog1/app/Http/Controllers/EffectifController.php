<?php

namespace App\Http\Controllers;

use App\Effectif;
use App\Categorie;
use Illuminate\Http\Request;
use DB;
use PDF;
use Dompdf\Dompdf;


//use League\Csv\Reader;

class EffectifController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $effectifs = Effectif::all();
      $categories = Categorie::all();
      return view('about',['effectifs'=>$effectifs
                                  ,'categories'=>$categories]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

     function pdfe(){
    	
    	 $categories =  \App\Categorie::all();
    	
      
    	$ab= Effectif::limit(100)->get();
    		
    	//return $effectifs;
    	$pdf= PDF::loadView('pdfe',(compact('ab','categories')));
    	$pdf->setPaper('a4','portrait');
    	
    	return $pdf->stream();
    
}
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Effectif  $effectif
     * @return \Illuminate\Http\Response
     */
    public function show(Effectif $effectif)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Effectif  $effectif
     * @return \Illuminate\Http\Response
     */
    public function edit(Effectif $effectif)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Effectif  $effectif
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Effectif $effectif)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Effectif  $effectif
     * @return \Illuminate\Http\Response
     */
    public function destroy(Effectif $effectif)
    {
        //
    }
}
