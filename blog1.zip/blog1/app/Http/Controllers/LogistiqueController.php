<?php

namespace App\Http\Controllers;

use App\Effectif;
use App\Logistique;
use Illuminate\Http\Request;
use DB;
use PDF;
use Dompdf\Dompdf;

class LogistiqueController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    

       public function create()
    {
      $effectifs =  \App\Effectif::all();
      $matchs =  \App\Match::select('Date')->distinct()->get();

      return view('logistique',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs]);
    }




    public function index()
    {
        $effectifs =  \App\Effectif::all();
      $matchs =  \App\Match::select('Date')->distinct()->get();

      return view('logistique',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs]);

    }



    public function action(Request $request)
    {

     if($request->ajax()){


        $effectifs =  \App\Effectif::all();
         $matchs =  \App\Match::select('Date')->distinct()->get();


          $val = $request->get('val');


            $output ="<thead class='thead-dark'>
                        <tr>
                        <th>Equipe</th>;
                          <th class='text-center'>Date</th>";
            for($i=$val;$i<($val+7);$i++){
                $output .="<th class='text-center'>".$matchs[$i]->Date."</th>";
            }
            $output .="</tr>
                        </thead>
                        <tbody>";

               $output .="<tr class='table-primary'>
                            <td rowspan='4' align='middle' style='vertical-align : middle;text-align:center;'>SCENIORS A</td>;
                            <td scope='row' style='font-weight: bold'>Maillot
                            </td>";
             
               for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('id');
                                       
                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	           
                         $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement');  
                          $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' and $eq=='SENIORS A'){
                    
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                       

                         
                         
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                             ->where('IDMatch',$idmatch)
                                               ->where('Tache','Maillot')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Maillot';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               }  
else {
                         		$output .="<label></label>
                            </td>";  
                         	              
                         }
               }
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                        ->where('Tache','Maillot')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
                $output .="</tr>"; 
    
                $output .="<tr class='table-primary'>
                            <td scope='row' style='font-weight: bold'>Buvette
                            </td>";
                         
               for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('id');

                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	        
                         $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement'); 
                $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' and $eq=='SENIORS A'){
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                             ->where('IDMatch',$idmatch)
                                               ->where('Tache','Buvette')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Buvette';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               }
               else {
                         		$output .="<label></label>
                            </td>";  
                         	              
                         }  }   
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                      ->where('Tache','Buvette')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
      $output .="</tr>"; 
                  $output .="<tr class='table-primary'>
                             <td scope='row' style='font-weight: bold'>Voiture
                             </td>";
                             for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('id');

                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	 $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement');  
                $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' or $eq!='SENIORS A'){
                         		$output .="<label></label>
                            </td>";  
               }
               else{
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                            ->where('IDMatch',$idmatch)
                                              ->where('Tache','Voiture')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Voiture';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               }  }   
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                       ->where('Tache','Voiture')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
                 $output .="</tr>";
                  $output .="<tr class='table-primary'>
                             <td scope='row' style='font-weight: bold'>Vestiaires
                            </td>";
                             for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                      ->value('id');

                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	   $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement');  
                $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' and $eq=='SENIORS A'){
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                            ->where('IDMatch',$idmatch)
                                             ->where('Tache','Vestiaires')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Vestiares';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               } else {
                         		$output .="<label></label>
                            </td>";  
                         	              
                         } }   
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                   ->where('Tache','Vestiaires')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
                $output .="</tr>";  
     
                
                
                
           $output .="<tr class='table-success'>
                            <td rowspan='4' align='middle' style='vertical-align : middle;text-align:center;'>SCENIORS B</td>;
                            <td scope='row' style='font-weight: bold'>Maillot
                            </td>";
             
               for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('id');
                                       
                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	           
                         $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement');  
                          $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' and $eq=='SENIORS B'){
                    
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                       

                         
                         
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                             ->where('IDMatch',$idmatch)
                                               ->where('Tache','Maillot')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Maillot';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               }  
else {
                         		$output .="<label></label>
                            </td>";  
                         	              
                         }
               }
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                        ->where('Tache','Maillot')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
                $output .="</tr>"; 
    
                $output .="<tr class='table-success'>
                            <td scope='row' style='font-weight: bold'>Buvette
                            </td>";
                         
               for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('id');

                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	        
                         $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement'); 
                $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' and $eq=='SENIORS B'){
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                             ->where('IDMatch',$idmatch)
                                               ->where('Tache','Buvette')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Buvette';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               }
               else {
                         		$output .="<label></label>
                            </td>";  
                         	              
                         }  }   
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                      ->where('Tache','Buvette')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
      $output .="</tr>"; 
                  $output .="<tr class='table-success'>
                             <td scope='row' style='font-weight: bold'>Voiture
                             </td>";
                             for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('id');

                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	 $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement');  
                $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' or $eq!='SENIORS B'){
                         		$output .="<label></label>
                            </td>";  
               }
               else{
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                            ->where('IDMatch',$idmatch)
                                              ->where('Tache','Voiture')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Voiture';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               }  }   
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                       ->where('Tache','Voiture')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
                 $output .="</tr>";
                  $output .="<tr class='table-success'>
                             <td scope='row' style='font-weight: bold'>Vestiaires
                            </td>";
                             for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                      ->value('id');

                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	   $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement');  
                $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' and $eq=='SENIORS B'){
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                            ->where('IDMatch',$idmatch)
                                             ->where('Tache','Vestiaires')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Vestiares';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               } else {
                         		$output .="<label></label>
                            </td>";  
                         	              
                         } }   
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                   ->where('Tache','Vestiaires')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
                $output .="</tr>";   

                
                
                
                
                
                
                
                
                
      $output .="<tr class='table-danger'>
                            <td rowspan='4' align='middle' style='vertical-align : middle;text-align:center;'>SCENIORS C</td>;
                            <td scope='row' style='font-weight: bold'>Maillot
                            </td>";
             
               for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('id');
                                       
                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	           
                         $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement');  
                          $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' and $eq=='SENIORS C'){
                    
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                       

                         
                         
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                             ->where('IDMatch',$idmatch)
                                               ->where('Tache','Maillot')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Maillot';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               }  
else {
                         		$output .="<label></label>
                            </td>";  
                         	              
                         }
               }
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                        ->where('Tache','Maillot')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
                $output .="</tr>"; 
    
                $output .="<tr class='table-danger'>
                            <td scope='row' style='font-weight: bold'>Buvette
                            </td>";
                         
               for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('id');

                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	        
                         $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement'); 
                $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' and $eq=='SENIORS C'){
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                             ->where('IDMatch',$idmatch)
                                               ->where('Tache','Buvette')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Buvette';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               }
               else {
                         		$output .="<label></label>
                            </td>";  
                         	              
                         }  }   
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                      ->where('Tache','Buvette')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
      $output .="</tr>"; 
                  $output .="<tr class='table-danger'>
                             <td scope='row' style='font-weight: bold'>Voiture
                             </td>";
                             for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('id');

                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	 $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement');  
                $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' or $eq!='SENIORS C'){
                         		$output .="<label></label>
                            </td>";  
               }
               else{
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                            ->where('IDMatch',$idmatch)
                                              ->where('Tache','Voiture')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Voiture';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               }  }   
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                       ->where('Tache','Voiture')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
                 $output .="</tr>";
                  $output .="<tr class='table-danger'>
                             <td scope='row' style='font-weight: bold'>Vestiaires
                            </td>";
                             for($i=$val;$i<($val+7);$i++){

                 $idmatch =  \App\Match::where('Date',$matchs[$i]->Date)
                                      ->value('id');

                                        
                	$output .="<td class='tdtache' id='".$idmatch."'>";
                	 if(\Auth::check()){
                	   $atch=  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('Deplacement');  
                $ideq =  \App\Match::where('Date',$matchs[$i]->Date)
                                       ->value('IDEquipe');
                          $eq = \App\Equipe::where('id',$ideq)
                                              ->value('NomEquipe');
                                       
               if($atch=='Domicile' and $eq=='SENIORS C'){
                                 $output .=" <select class='form-control tache'>
                                    <option data-tokens='$i' value='empty' selected></option>";
                	  foreach ($effectifs as $effectif) {

                	  $ideffectif = \App\Logistique::where('IDEffectif',$effectif->id)
                                            ->where('IDMatch',$idmatch)
                                             ->where('Tache','Vestiaires')
                                              ->value('id');
                    
                     if($ideffectif !== NULL){
                         $selected = 'selected';
                	  }
                    else  $selected =" ";

                     
                	  	  $output .=       "<option  value='".$effectif->id."' $selected >".$effectif->Nom." ".
                            $effectif->Prenom."</option>";
                            $tachelog='Vestiares';
                	  
                	 
                	  }
                            $output .= "</select>
                            </td>";
               } else {
                         		$output .="<label></label>
                            </td>";  
                         	              
                         } }   
       else{
       	    $ideffectif = \App\Logistique::where('IDMatch',$idmatch)
       	                                   ->where('Tache','Vestiaires')
                                              ->value('IDEffectif');
           foreach ($effectifs as $effectif) { 
           	if($effectif->id==$ideffectif)
           	$output .="<label class='i'>$effectif->Nom $effectif->Prenom	</label>
                            </td>";        
           }
       	
	
     }
               
     }
                $output .="</tr>";             
                
                
                
                
                
                
                

               $output.=" <script>

    

            $('.i').each(function(){
              var val = $(this).text();
              console.log(val);
               if(val == 'empty'){
                $(this).parent().css('background-color','white')
              } else
             {
                $(this).parent().css({'background-color':'black',
                              'color' : 'white'})
                              
              }
            });	
            
            
            
            
              $('.tdtache').each(function(){
              var val = $(this).text();
              console.log(val);
               if(val == 'empty'){
                $(this).parent().css('background-color','white')
              } else
             {
                $(this).parent().css({'background-color':'black',
                              'color' : 'black'})
                              
              }
            });
            $('.tache option:selected').each(function(){
              var val = $(this).val();
               if(val == 'empty'){
                $(this).parent().css('background-color','white')
              } else
             {
                $(this).parent().css({'background-color':'black',
                              'color' : 'white'})
                              
              }
            
            });
            

               
               
               
               
               
                          $('.tache').change(function(){

                              var val = $(this).val();
                              var td = $(this).parent().attr('id');
                              var nom = $(this).parent().siblings(':first-child').text();

                           $.ajax({
                                  url:'/insertlog',
                                   method:'GET',
                                   data:{ ideffectif : val, id : td, nom : nom  },
                                   success:function(data)
                                   {
                                     if(val == 'empty'){
                                       alert('Joueur supprimé');
                                     } else
                                     alert('Joueur enregitré');
                                   },
                                     error: function(response) {
                                console.log(response);
                                     }
                                 });
                       });
                       </script>";


              $data = array('table_data' => $output);
              echo json_encode($data);


     }



    }

     function insere (Request $request){

      $ideffectif = $request->get('ideffectif');
      $idajax = $request->get('id');
      $tacheajax = $request->get('nom');

      $matchs = \App\Match::select('Date')->distinct()->get();

     if($ideffectif == 'empty'){
       $id =  Logistique::where('IDMatch',$idajax)
                        ->value('id');
          Logistique::destroy($id);
     }else if( Logistique::where('IDMatch',$idajax)
                          ->count()>0){
             Logistique::where('IDMatch',$idajax)
                    ->update(['IDEffectif' => $ideffectif]);
     }
       else {
       Logistique::create([
          'IDEffectif' => $ideffectif,
          'IDMatch' => $idajax,
          'Tache' => $tacheajax
        ]);
     }


     }


     public function store(Request $request)
    {

      $effectifs =  \App\Effectif::all();
      $matchs =  \App\Match::select('Date')->distinct()->get();

      $val = $request->get('val');

      return $val;

      return view('logistique',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs]);

    }

     function pdfl(){
    	 $effectifs =  \App\Effectif::all();
    	 $matchs =  \App\Match::all();
      
    	$ab= Logistique::limit(100)->get();
    		//return $ab;
    		//return $effectifs;
    	$pdf= PDF::loadView('pdfl',(compact('ab','effectifs','matchs')));
    	$pdf->setPaper('a4','portrait');
    	
    	return $pdf->stream();
    
}
    public function show(Logistique $logistique)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Logistique  $logistique
     * @return \Illuminate\Http\Response
     */
    public function edit(Logistique $logistique)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Logistique  $logistique
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Logistique $logistique)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Logistique  $logistique
     * @return \Illuminate\Http\Response
     */
    public function destroy(Logistique $logistique)
    {
        //
    }
}