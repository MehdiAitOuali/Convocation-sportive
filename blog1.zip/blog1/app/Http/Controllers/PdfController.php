<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;


class PdfController extends Controller
{
    function index(){
    	
    	$customer=$this->get_customer();
    	return view('pdf')->with('customer',$customer);
    }
    function get_customer(){
    	
    	$customer=DB::table('Absence')
    	          ->limit(10)
    	          ->get();
    	
    	 return $customer;
    }
}
