<?php

namespace App\Http\Controllers;

use App\Absence;
use Illuminate\Http\Request;
use DB;
use PDF;
use Dompdf\Dompdf;

class AbsenceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
      $effectifs =  \App\Effectif::all();
      $matchs =  \App\Match::select('Date')->distinct()->get();
      
      
      return view('absence',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs]);

    }
   /*    public function returnpdf()
    {
      $effectifs =  \App\Effectif::all();
      $matchs =  \App\Match::select('Date')->distinct()->get();
      $aitouali=$this->pdf();
      
      return view('pdf',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs
                        'aitouali'=>$aitaouli]);

    }*/


    public function action(Request $request)
    {
       if($request->ajax()){
        $effectifs =  \App\Effectif::all();
         $matchs =  \App\Match::select('Date')->distinct()->get();

          $val = $request->get('val');
          $motifajax = $request->get('motif');


            $output ="<thead class='thead-dark'>
                        <tr>
                          <th class='text-center'>#</th>";
            for($i=$val;$i<($val+7);$i++){
                $output .="<th class='text-center'>".$matchs[$i]->Date."</th>";
            }
            $output .="</tr>
                        </thead>
                        <tbody>";
            foreach ($effectifs as $effectif) {
               $output .="<tr>
                            <td scope='row' style='font-weight: bold'>".$effectif->Nom." ".
                            $effectif->Prenom."
                            </td>";
              for($i=$val;$i<($val+7);$i++){

                $ideffectif = \App\Effectif::where('Nom',$effectif->Nom)
                                             ->where('Prenom',$effectif->Prenom)
                                              ->value('id');
               if($ideffectif !== NULL){
                 $motifabs = Absence::where('DateAbsence',$matchs[$i]->Date)->where(
                                             'IDEffectif',$ideffectif)->
                                             value('Motif');
                }

                 if(\Auth::check()){
                  $output .="<td class='tdmotif' id='$i'>
                                  <select  class='form-control motif'>
                                    <option value='empty' selected></option>";
                                    ($motifabs == 'Blessé') ? $select = 'selected' : $select ='false';
                  $output .=       "<option value='Blessé' $select >Blessé</option>";
                                    ($motifabs == 'Non licencié') ? $select = 'selected' : $select ='false';
                  $output .=       "<option value='Non licencié' $select>Non licencié</option>";
                                    ($motifabs == 'Suspendu') ? $select = 'selected' : $select ='false';
                  $output .=       "<option value='Suspendu' $select>Suspendu</option>
                                  </select>
                            </td>";
                 } else {
                   $output .="<td class='tdmotif' id='$i'>";

                                 if($motifabs == 'Blessé'){
                   $output .=       "<label align='center' >Blessé</label>";

                 }else if($motifabs == 'Non licencié'){
                   $output .=       "<label align='center'>Non licencié</label>";
                 }else if($motifabs == 'Suspendu'){
                   $output .=       "<label align='center' >Suspendu</label>";
                                 }else {
                  $output .=       "<label value='empty' ></label>";
                                 }
                  $output .= "</td>";

                 }
              }
              $output.="</tr>";
            }
            $output.="</tbody>";
            $output.=" <script>

            $('.motif option:selected').each(function(){
              var val = $(this).val();
              if(val == 'Blessé'){
                $(this).parent().css({'background-color':'red',
                              'color' : 'white'})
              }else if(val == 'Suspendu'){
                $(this).parent().css({'background-color':'orange',
                              'color' : 'white'})
              }else if(val == 'Non licencié'){
                $(this).parent().css({'background-color':'purple',
                              'color' : 'white'})
              }else if(val == 'empty'){
                $(this).parent().css('background-color','white')
              }
            });

            $('.tdmotif').each(function(){
              var val = $(this).text();
              console.log(val);
              if(val == 'Blessé'){
                $(this).css({'background-color':'red',
                              'color' : 'white'
                              ,'font-weight' : 'bold'})
              }else if(val == 'Suspendu'){
                $(this).css({'background-color':'orange',
                              'color' : 'white'
                              ,'font-weight' : 'bold'})
              }else if(val == 'Non licencié'){
                $(this).css({'background-color':'purple',
                              'color' : 'white'
                              ,'font-weight' : 'bold'})
              }else if(val == 'empty'){
                $(this).css('background-color','white')
              }
            });

             $('.motif').change(function(){
                var val = $(this).val();
                if(val == 'Blessé'){
                  $(this).css({'background-color' : 'red',
                                'color' : 'white'})
                }else if(val == 'Suspendu'){
                  $(this).css({'background-color':'orange',
                                'color' : 'white'})
                }else if(val == 'Non licencié'){
                  $(this).css({'background-color':'purple',
                                'color' : 'white'})
                }else if(val == 'empty'){
                  $(this).css('background-color','white')
                }

                var val = $(this).val();
                var td = $(this).parent().attr('id');
                var nom = $(this).parent().siblings(':first-child').text();
                   $.ajax({
                    url:'/insert',
                     method:'GET',
                     data:{ motif : val, id : td, nom : nom  },
                     success:function(data)
                     {
                       if(val == 'empty'){
                         alert('Cette absence est bien supprimée');
                       } else
                       alert('L\'absence est bien enregitrée');
                     },
                       error: function(response) {
                           console.log(response);
                       }
                   });
         });

             </script>";

              $data = array('table_data' => $output);
              echo json_encode($data);

       }
    }

    function inserer(Request $request){

      $motifajax = $request->get('motif');
      $idajax = $request->get('id');
      $nom = $request->get('nom');

      $nom = explode(' ',$nom);
      $matchs = \App\Match::select('Date')->distinct()->get();
      $match = $matchs[$idajax]->Date;
      $ideffectif = \App\Effectif::where('Nom',$nom[0])
                                   ->where('Prenom',$nom[1])
                                    ->value('id');

     if($motifajax == 'empty'){
       $id =  Absence::where('IDEffectif',$ideffectif)
              ->where('DateAbsence',$match)->value('id');
          Absence::destroy($id);
     }else if( Absence::where('IDEffectif',$ideffectif)
            ->where('DateAbsence',$match)
            ->count()>0){
              Absence::where('IDEffectif',$ideffectif)
                    ->where('DateAbsence',$match)
                    ->update(['Motif' => $motifajax]);
     }
       else {
       Absence::create([
          'IDEffectif' => $ideffectif,
          'DateAbsence' => $match,
          'Motif' => $motifajax
        ]);
     }


    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $effectifs =  \App\Effectif::all();
      $matchs =  \App\Match::select('Date')->distinct()->get();

      return view('absence',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

      $effectifs =  \App\Effectif::all();
      $matchs =  \App\Match::select('Date')->distinct()->get();

      $val = $request->get('val');

      return $val;

      return view('absence',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs]);

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Absence  $absence
     * @return \Illuminate\Http\Response
     * 
     */
    function pdf(){
    	 $effectifs =  \App\Effectif::all();
      
    	$ab= Absence::limit(100)->get();
    		//return $ab;
    		//return $effectifs;
    	$pdf= PDF::loadView('pdf',(compact('ab','effectifs')));
    	$pdf->setPaper('a4','portrait');
    	
    	return $pdf->stream();
    
}
    public function show(Absence $absence)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Absence  $absence
     * @return \Illuminate\Http\Response
     */
    public function edit(Absence $absence)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Absence  $absence
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Absence $absence)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Absence  $absence
     * @return \Illuminate\Http\Response
     */
    public function destroy(Absence $absence)
    {
        //
    }
}
