<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NonConvoc extends Model
{
  protected $table = 'NON_CONVOC';

  protected $fillable = [
      'IDEffectif', 'DateNC','Statut'
  ];

 public $timestamps = false;

}
