
$(document).ready(function(){

  // $('.selectjs').each(function(){
  //               var val = $(this).val();
  //               console.log(val);
  //                if(val == 'empty'){
  //                 $(this).parent().css('background-color','white')
  //               } else
  //              {
  //                 $(this).parent().css({'background-color':'black',
  //                               'color' : 'black'})
  //
  //               }
  //             });

  $('.selectj option:selected').each(function(){
    var val = $(this).val();
     if(val == 'empty'){
      $(this).parent().css('background-color','white')
    } else
   {
      $(this).parent().css({'background-color':'black',
                    'color' : 'white'})

    }

  });


 var datematch = $("#selectconvocation").val();

  var nonconvoques = [];
  var convoques = [];
  $('#tabconvocation select').each(function(){
     if($(this).val() != 'empty')
         convoques.push($(this).val());
  });
  $('#bodynonconvoc td').each(function(){
     nonconvoques.push($(this).attr('id'));
  });


 //$('').each(function(){
    $('#tabconvocation select').change(function(){
       var nonconvoques = [];
       $('#bodynonconvoc td').each(function(){
          nonconvoques.push($(this).attr('id'));
       });
       // var convoques = [];
       // $('#tabconvocation select').each(function(){
       //    if($(this).val() != 'empty')
       //        convoques.push($(this).val());
       // });

        ideffectif = $(this).val();

       if(ideffectif == 'empty'){

           var selectionner = [];
            $('#tabconvocation select').each(function(){
              if ($(this).find('option:selected')){
                if( $(this).val() != 'empty'){
                   selectionner.push($(this).val());
                }
              }
            });

            for(i=0;i<convoques.length;i++){
               if(selectionner.indexOf(convoques[i]) == -1){
                 nonconvoques.push(convoques[i]);
                 ind = convoques.indexOf(convoques[i]);
                 convoques.splice(ind,1);

               }
            }

       }else{
         indice = nonconvoques.indexOf(ideffectif);
         nonconvoques.splice(indice,1);
         convoques.push(ideffectif);
       }

       // for(i=0;i<convoques.length;i++)
       //   console.log(convoques[i]);

       $('.selectj option:selected').each(function(){
         var val = $(this).val();
          if(val == 'empty'){
           $(this).parent().css('background-color','white')
         } else
        {
           $(this).parent().css({'background-color':'black',
                         'color' : 'white'})

         }

       });

       $.ajax({
        url:"/convoquer",
         method:'GET',
         data:{ convoques:convoques,
                nonconvoques:nonconvoques,
                date:datematch},
         dataType:'json',
         success:function(data)
         {

           $('.selectj').each(function(){
             if($(this).val() != "empty"){
               $(this).html("<option value='"+$(this).find('option:selected').val()+"' selected>"
                            +$(this).find('option:selected').text()
                            +"</option><option value='empty'style='text-align:center'>  <-- Effacer --></option>");
             }else{
               $(this).html(data.option);
             }

           });

           $("#bodynonconvoc").html(data.nonconvoc);

          $('#script2').html(data.script);

         },
           error: function(response) {
               console.log(response);
           }
       });


    });
 //});



});
