 <!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>PDF absence</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

th {
  background-color: black;
  color: white;
  border: 1px solid #dddddd;
  text-align: left;
 
}
td {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;

}
thead{
background:black;
}


</style>
</head>
<body>
<table>
 <caption>LES ABSENCES</caption>
<thead>

<tr>
<th>Nom</th>
<th>Date</th>
<th>Motif</th>



</tr>
</thead>
<tbody>

@foreach($ab as $abs)

<tr>
@foreach($effectifs as $effectif)
@if($effectif->id==$abs->IDEffectif)
<td>{{$effectif->Nom}} {{$effectif->Prenom}}</td>
@endif 
@endforeach

<td>{{$abs->DateAbsence}}</td>
<td>{{$abs->Motif}}</td>
</tr>	
@endforeach



</tbody>
</table>

</body>
</html> 