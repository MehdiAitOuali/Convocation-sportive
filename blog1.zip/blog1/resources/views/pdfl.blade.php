 <!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>PDF logistique</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
th {
  background-color: black;
  color: white;
  border: 1px solid #dddddd;
  text-align: left;
 
}
td {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;

}
thead{
background:black;
}

</style>
</head>
<body>
<table>
 <caption>LA LOGISTIQUE</caption>
<thead >

<tr>
<th color='white'>Nom</th>
<th color='white'>Date</th>
<th color='white'>Tache</th>



</tr>
</thead>
<tbody>

@foreach($ab as $abs)

<tr>
@foreach($effectifs as $effectif)
@if($effectif->id==$abs->IDEffectif)
<td>{{$effectif->Nom}} {{$effectif->Prenom}}</td>
@endif 
@endforeach
@foreach($matchs as $match)
@if($match->id==$abs->IDMatch)
<td>{{$match->Date}}</td>
@endif 
@endforeach
<td>{{$abs->Tache}}</td>
</tr>	
@endforeach



</tbody>
</table>

</body>
</html> 