<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>@yield('title')</title>
<style>

 #tab,#tab>th,#tab>td {

 table-layout: fixed;
 border-collapse: collapse;
 border: 3px solid purple;

 }

</style>
  </head>
  <body>


<table width="1000">
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td>
      <a href="/"><h4>Acceuil</h4></a>
    </td>
  </tr>
  <tr>
    <td><a href="/effectif"><h4>Les joueurs</h4></a></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>


  <tr>
    <td><a href="/absence/create"><h4>Ajouter une Absence</h4></a></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><a href="/logistique/create"><h4>Ajouter une tâche</h4></a></td>
    <td></td>
    <td></td>
    <td></td>
 </tr>

</table>

<div style="padding-left : 400px">
@yield('contenu')
</div>

<div>

</div>

  </body>
</html>
