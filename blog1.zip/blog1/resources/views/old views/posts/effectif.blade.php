@extends('layouts.app')

@section('title','Effectif')

@section('content')

<div id="contenu" style="padding-left : 200px">

<table width="800px" id="tab">
  <tr id="tab">
    <th>Nom</th>
    <th>Prenom</th>
    <th>Catégorie</th>
    <th>Date de naissance</th>
  </tr>

 <?php foreach ( $effectifs as $effectif): ?>
  <tr id="tab">
   <td>{{ $effectif->Nom }}</td>
   <td>{{ $effectif->Prenom }}</td>
   <td>{{ $categories->find($effectif->IDCategorie)->NomCategorie }}</td>
   <td>{{ $effectif->date_naissance }}</td>
  </tr>
 <?php endforeach; ?>

</div>

@endsection
