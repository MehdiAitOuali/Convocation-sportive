@extends('layouts.app')

@section('content')

<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

<div id="contenu" style="padding-left : 200px">

    <h2>Logistique</h2>

<form action="/logistique" method="post">
{{ csrf_field() }}
  Nom:
  <p>
    <select name="nom">

      <?php foreach ($effectifs as $effectif): ?>

        <?php $val = $effectif->Nom." ".$effectif->Prenom;
              $select = "";
        ?>

        @if(old('nom') == $val)
        <?php $select = "selected"; ?>
        @endif

         <option value="{{ $val }}" {{ $select }}>
                        {{ $val }}
          </option>
      <?php endforeach; ?>

   </select>

  </p>

  @if($errors->has('nom'))
    <p>{{ $errors->first('nom') }}</p>
    @endif

   date:
<p>    <select name="date">

    <?php foreach ($matchs as $match): ?>

          <?php $val = $match->Date; ?>

       <option value="{{ $val }}">
                      {{ $val }}
        </option>
    <?php endforeach; ?>

 </select>
</p>

@if($errors->has('date'))
  <p>{{ $errors->first('date') }}</p>
  @endif
Tache:
<p>
  <select name="tache">
  <option value="Maillot">Maillot</option>
  <option value="Vestiaires">Vestiaires</option>
  <option value="Buvette">Buvette</option>
  <option value="Voiture">Voiture</option>
</select>
</p>

<br><br>
  <input type="submit" value="Submit">
</form>

</div>

  </body>
</html>

@endsection
