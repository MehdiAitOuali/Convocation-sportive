@extends('layouts.app')

@section('content')

<div id="contenu" style="padding-left : 200px">

    <h2>Absence</h2>

    <form action="/absence" method="post">
   {{ csrf_field() }}
     Nom:
        <p>

      <select name="nom">

        <?php foreach ($effectifs as $effectif): ?>

          <?php $val = $effectif->Nom." ".$effectif->Prenom;
                $select = "";
          ?>

          @if(old('nom') == $val)
          <?php $select = "selected"; ?>
          @endif

           <option value="{{ $val }}" {{ $select }}>
                          {{ $val }}
            </option>
        <?php endforeach; ?>

     </select>

    </p>

     @if($errors->has('nom'))
    <p>{{ $errors->first('nom') }}</p>
    @endif


      date:
    <p>
     <!-- <input type="date" name="date" value="{{old('date')}}"> -->

    <select name="date">

      <?php foreach ($matchs as $match): ?>

            <?php $val = $match->Date; ?>

         <option value="{{ $val }}">
                        {{ $val }}
          </option>
      <?php endforeach; ?>

   </select>

    </p>

      @if($errors->has('date'))
     <p>{{ $errors->first('date') }}</p>
     @endif

     Motif:
     <p>
     <select name="motif">
     <option value="Blessé">Blessé</option>
     <option value="Non licencié">Non licencié</option>
     <option value="Suspendu">Suspendu</option>
     </select>
    </p>

      @if($errors->has('motif'))
     <p>{{ $errors->first('motif') }}</p>
     @endif



    <p> <input type="submit" value="Submit"></p>
   </form>

</div>

@stop
