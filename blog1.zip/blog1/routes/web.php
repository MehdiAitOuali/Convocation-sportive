<?php
use App\Http\Controllers\CategorieController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
});
*/
Route::get('/', function () {
    return view('auth.login');
});

Route::resource('categorie','CategorieController');

//Route::get('/equipe', 'EquipeController@index');


Route::resource('equipe','EquipeController');

Route::resource('effectif','EffectifController');
Route::get('/effectif-pdf','EffectifController@pdfe');

Route::resource('absence', 'AbsenceController');
//Route::get('/absence', 'AbsenceController@index');
Route::get('/read','AbsenceController@action')->name('absence.action');
Route::get('/insert','AbsenceController@inserer');
Route::get('/absence-pdf','AbsenceController@pdf');

Route::resource('logistique', 'LogistiqueController');
Route::get('/lire', 'LogistiqueController@action');
Route::get('/insertlog', 'LogistiqueController@insere');
Route::get('/logistique-pdf','LogistiqueController@pdfl');


Route::resource('convocation', 'ConvocationController');
Route::get('/readconvocation','ConvocationController@selectdate');
Route::get('/convoquer','ConvocationController@convoquer');
Route::get('/bdconvoc','ConvocationController@bdconvoc');
Route::get('/convocation-pdf','ConvocationController@pdfc');
Auth::routes();

Auth::routes();

Route::get('home', 'HomeController@index')->name('home');
