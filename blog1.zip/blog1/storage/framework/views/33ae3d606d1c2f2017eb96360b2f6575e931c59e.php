<?php $__env->startSection('content'); ?>
<div>
<h2>
   Nous avons bien recu vos informations: <?php echo e($rqst['nom']); ?>

    <?php echo e($rqst['date']); ?> <?php echo e($rqst['motif']); ?>

</h2>
</div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>