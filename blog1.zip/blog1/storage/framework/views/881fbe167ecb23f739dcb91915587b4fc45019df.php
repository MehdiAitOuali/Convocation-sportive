<?php $__env->startSection('content'); ?>

<div id="contenu" style="padding-left : 200px">

    <h2>Absence</h2>

    <form action="/absence" method="post">
   <?php echo e(csrf_field()); ?>

     Nom:
        <p>

      <select name="nom">

        <?php foreach ($effectifs as $effectif): ?>

          <?php $val = $effectif->Nom." ".$effectif->Prenom;
                $select = "";
          ?>

          <?php if(old('nom') == $val): ?>
          <?php $select = "selected"; ?>
          <?php endif; ?>

           <option value="<?php echo e($val); ?>" <?php echo e($select); ?>>
                          <?php echo e($val); ?>

            </option>
        <?php endforeach; ?>

     </select>

    </p>

     <?php if($errors->has('nom')): ?>
    <p><?php echo e($errors->first('nom')); ?></p>
    <?php endif; ?>


      date:
    <p>
     <!-- <input type="date" name="date" value="<?php echo e(old('date')); ?>"> -->

    <select name="date">

      <?php foreach ($matchs as $match): ?>

            <?php $val = $match->Date; ?>

         <option value="<?php echo e($val); ?>">
                        <?php echo e($val); ?>

          </option>
      <?php endforeach; ?>

   </select>

    </p>

      <?php if($errors->has('date')): ?>
     <p><?php echo e($errors->first('date')); ?></p>
     <?php endif; ?>

     Motif:
     <p>
     <select name="motif">
     <option value="Blessé">Blessé</option>
     <option value="Non licencié">Non licencié</option>
     <option value="Suspendu">Suspendu</option>
     </select>
    </p>

      <?php if($errors->has('motif')): ?>
     <p><?php echo e($errors->first('motif')); ?></p>
     <?php endif; ?>



    <p> <input type="submit" value="Submit"></p>
   </form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>