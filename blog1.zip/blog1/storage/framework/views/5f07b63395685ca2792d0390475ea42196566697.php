<?php $__env->startSection('content'); ?>

<div id="contenu" style="padding-left : 200px;padding-top : 50px">
<h1>Bonjour vous êtes à l'accueil</h1>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>