

<?php $__env->startSection('content'); ?>

<style>

  .tdconvoc{ font-weight: bold;}

</style>


   <div class="container" >
       <div class="row" style="margin : 2%;margin-left : 30%">
      <h2>CONVOCATIONS</h2>
    </div>
    <div class="row">

 <div class="col-xs-12 col-sm-6 col-md-8">



<table class="table  table-bordered table-striped table-sm  table-hover"
     style="background-color:white">
<thead class="thead-dark">
   <tr>
    <th> DATE </th>
    <td>
      <select id="selectconvocation" class="custom-select mr-sm-2">
  			<?php foreach ($matchs as $match): ?>
           <option value="<?php echo e($match->Date); ?>"> <?php echo e($match->Date); ?>

           </option>
        <?php endforeach; ?>
  		</select>
    </td>
   </tr>
</thead>

<tbody class="thead-dark" id="tabconvocation">
  <tr>
       <th>EQUIPE</th>
       <td id="tdequipe"></td>
  </tr>

  <tr>
    <th>COMPETITION</th>
    <td id="tdcompetition" class="tdconvoc"></td>
   </tr>
   <tr>
       <th>EQUIPE ADVERSE</th>
       <td id="tdadverse" class="tdconvoc"></td>
   </tr>
   <tr>
    <th>SITES</th>
    <td id="tdsite" class="tdconvoc"></td>
  </tr>
  <tr>
    <th>TERRAIN</th>
    <td id="tdterrain" class="tdconvoc"></td>
  </tr>
  <tr>
     <th>HEURE</th>
     <td id="tdheure" class="tdconvoc"></td>
  </tr>
  <tr>
      <th align="right">Joueur 1</th>
      <td id="td1"></td>
  </tr>
  <tr>
      <th align="right">Joueur 2</th>
      <td id="td2"></td>
  </tr>
  <tr>
      <th align="right">Joueur 3</th>
      <td id="td3"></td>
  </tr>
  <tr>
      <th align="right">Joueur 4</th>
      <td id="td4"></td>
  </tr>
  <tr>
      <th align="right">Joueur 5</th>
      <td id="td5"></td>
  </tr>
  <tr>
      <th align="right">Joueur 6</th>
      <td id="td6"></td>
  </tr>
  <tr>
      <th align="right">Joueur 7</th>
      <td id="td7"></td>
  </tr>
  <tr>
      <th align="right">Joueur 8</th>
      <td id="td8"></td>
  </tr>
  <tr>
      <th align="right">Joueur 9</th>
      <td id="td9"></td>
  </tr>
  <tr>
      <th align="right">Joueur 10</th>
      <td id="td10"></td>
  </tr>
  <tr>
      <th align="right">Joueur 11</th>
      <td id="td11"></td>
  </tr>
  <tr>
      <th align="right">Remplaçant 1</th>
      <td id="td12"></td>
  </tr>
  <tr>
      <th align="right">Remplaçant 2</th>
      <td id="td13"></td>
  </tr>
  <tr>
      <th align="right">Remplaçant 3</th>
      <td id="td14"></td>
  </tr>
  <tr>
      <th align="right">Remplaçant 4</th>
      <td id="td15"></td>
  </tr>
  <tr>
      <th>Responsable</th>
      <td id="tdresponsable" class="tdconvoc"></td>
  </tr>
  </tbody>
<!--

<tr>
    <th>DIRIGEANTS</th>
    <td><input type="text"></td>
  </tr>

<tr>
    <th>ARBITRE</th>
    <td><input type="text"></td>
  </tr>


<tr>
    <th rowspan="3" ><div style="margin-bottom : 22%">
                      LOGISTIQUE</div></th>
    <td>VOITURES : <input type="text"></td>
    <tr> <td>BUVETTES : <input type="text"></td></tr>
    <tr>  <td>MAILLOTS : <input type="text"></td></tr>
 </tr>
-->

 </table>
</div>


<!-- Tableau pour absence et les non convoques -->




<div class="col-xs-6 col-md-2">


 <table class="table  table-bordered table-striped table-sm  table-hover"
    style="background-color:white" id="bodynonconvoc" >
  </table>

</div>



<div class="col-xs-6 col-md-2">
	<table class="table  table-bordered table-striped table-sm  table-hover" style="background-color:white"
          id="bodyabsence">
 </table>
</div>

</div>
</div>

<script>

$(document).ready(function(){

  var valeur = $("#selectconvocation").val();
  changeselect(valeur);

  $("#selectconvocation").change(function(){
		 var valeur = $("#selectconvocation").val();
         changeselect(valeur);
	});

  function changeselect(val){
    $.ajax({
     url:"/readconvocation",
      method:'GET',
      data:{ val:val },
      dataType:'json',
      success:function(data)
      {
        $('#tdequipe').html(data.equipe);
        $('#tdcompetition').html(data.compet);
        $('#tdadverse').html(data.adverse);
        $('#tdsite').html(data.site);
        $('#tdterrain').html(data.terrain);
        $('#tdheure').html(data.heure);
        $('#td1').html(data.j1);
        $('#td2').html(data.j2); $('#td3').html(data.j3);
        $('#td4').html(data.j4); $('#td5').html(data.j5);
        $('#td6').html(data.j6); $('#td7').html(data.j7);
        $('#td8').html(data.j8); $('#td9').html(data.j9);
        $('#td10').html(data.j10); $('#td11').html(data.j11);
        $('#td12').html(data.j12); $('#td13').html(data.j13);
        $('#td14').html(data.j14); $('#td15').html(data.j15);
        $('#tdresponsable').html(data.responsable);

        $('#bodynonconvoc').html(data.nonconvoc);
        $('#bodyabsence').html(data.absence);

      },
        error: function(response) {
            console.log(response);
        }
    });
  }

});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>