<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>PDF logistique</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
th {
  background-color: black;
  color: white;
  border: 1px solid #dddddd;
  text-align: left;
 
}
td {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;

}
thead{
background:black;
}

</style>
</head>
<body>
<table>
 <caption>EFFECTIF</caption>
<thead >

<tr>
<th > 	Nom</th>
    <th> Prenom</th>
    <th >Catégorie</th>
    <th>Date de naissance</th>


</tr>
</thead>
<tbody>


<?php $__currentLoopData = $ab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
   <td><?php echo e($abs->Nom); ?></td>
   <td ><?php echo e($abs->Prenom); ?></td>
   <td><?php echo e($categories->find($abs->IDCategorie)->NomCategorie); ?></td>
   <td><?php echo e($abs->date_naissance); ?></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</tbody>
</table>

</body>
</html> 



<?php /**PATH C:\Users\lbrah\blog1\resources\views/pdfe.blade.php ENDPATH**/ ?>