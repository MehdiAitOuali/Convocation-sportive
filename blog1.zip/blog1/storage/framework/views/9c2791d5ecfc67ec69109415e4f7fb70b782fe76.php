<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

<div id="contenu" style="padding-left : 200px">

    <h2>Logistique</h2>

<form action="/logistique" method="post">
<?php echo e(csrf_field()); ?>

  Nom:
  <p>
    <select name="nom">

      <?php foreach ($effectifs as $effectif): ?>

        <?php $val = $effectif->Nom." ".$effectif->Prenom;
              $select = "";
        ?>

        <?php if(old('nom') == $val): ?>
        <?php $select = "selected"; ?>
        <?php endif; ?>

         <option value="<?php echo e($val); ?>" <?php echo e($select); ?>>
                        <?php echo e($val); ?>

          </option>
      <?php endforeach; ?>

   </select>

  </p>

  <?php if($errors->has('nom')): ?>
    <p><?php echo e($errors->first('nom')); ?></p>
    <?php endif; ?>

   date:
<p>    <select name="date">

    <?php foreach ($matchs as $match): ?>

          <?php $val = $match->Date; ?>

       <option value="<?php echo e($val); ?>">
                      <?php echo e($val); ?>

        </option>
    <?php endforeach; ?>

 </select>
</p>

<?php if($errors->has('date')): ?>
  <p><?php echo e($errors->first('date')); ?></p>
  <?php endif; ?>
Tache:
<p>
  <select name="tache">
  <option value="Maillot">Maillot</option>
  <option value="Vestiaires">Vestiaires</option>
  <option value="Buvette">Buvette</option>
  <option value="Voiture">Voiture</option>
</select>
</p>

<br><br>
  <input type="submit" value="Submit">
</form>

</div>

  </body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>