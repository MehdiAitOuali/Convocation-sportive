<?php $__env->startSection('title','Absence'); ?>

<?php $__env->startSection('contenu'); ?>

<table width="800px" id="tab">
  <tr id="tab">
    <th>Nom</th>
    <th>Prenom</th>
    <th>Date</th>
    <th>Motif</th>
  </tr>

 <?php foreach ( $absences as $absence): ?>
  <tr id="tab">
   <td><?php echo e($absence->DateAbsence); ?></td>
   <td><?php echo e($absence->Motif); ?></td>
   <td><?php echo e( ); ?></td>
   <td>{{]}</td>
  </tr>
 <?php endforeach; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>