<?php

use Illuminate\Database\Seeder;

class EffectifSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::statement('SET FOREIGN_KEY_CHECKS=0');
      DB::table('EFFECTIF')->truncate();
      DB::statement('SET FOREIGN_KEY_CHECKS=1');

      $fichier = fopen('/var/www/html/blog/csv/effectif.csv','r');

        $i=false;
        while($data = fgetcsv($fichier,1000,",")){
          if($i){

            $name = explode(" ", $data[1]);

            $categorie =  explode(" ", $data[3]);
            if($categorie[0] == "Senior") $categorie[0]="SENIORS";

            $datefr= explode("/", $data[2]);
            $dateang = $datefr[2]."-".$datefr[1]."-".$datefr[0];

            DB::table('EFFECTIF')->insert([
            'Nom' => $name[0],
            'Prenom' => $name[1],
            'TypeLicence' => $data[0],
            'IDCategorie' =>
             DB::table('CATEGORIE')->
            where('NomCategorie',$categorie[0])->value('id'),
            'date_naissance' => $dateang,
            'adresse' => $data[6],
            'mobile' => $data[11],
            'email' => $data[12]
          ]);
          }
          else {
            $i=true;
          }

        }

    }

}
