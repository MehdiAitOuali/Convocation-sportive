<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToNONCONVOCTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('NON_CONVOC', function(Blueprint $table)
		{
			$table->foreign('IDEffectif', 'NON_CONVOC_ibfk_1')->references('id')->on('EFFECTIF')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('NON_CONVOC', function(Blueprint $table)
		{
			$table->dropForeign('NON_CONVOC_ibfk_1');
		});
	}

}
