<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToABSENCETable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('ABSENCE', function(Blueprint $table)
		{
			$table->foreign('IDEffectif', 'ABSENCE_ibfk_1')->references('id')->on('EFFECTIF')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('ABSENCE', function(Blueprint $table)
		{
			$table->dropForeign('ABSENCE_ibfk_1');
		});
	}

}
