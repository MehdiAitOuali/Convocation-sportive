<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToMATCHSTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('MATCHS', function(Blueprint $table)
		{
			$table->foreign('IDEquipe', 'MATCHS_ibfk_1')->references('id')->on('EQUIPE')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('MATCHS', function(Blueprint $table)
		{
			$table->dropForeign('MATCHS_ibfk_1');
		});
	}

}
