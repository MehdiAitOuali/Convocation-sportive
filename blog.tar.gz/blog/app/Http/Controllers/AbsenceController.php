<?php

namespace App\Http\Controllers;

use App\Absence;
use Illuminate\Http\Request;

class AbsenceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $effectifs =  \App\Effectif::all();
      $matchs =  \App\Match::all();

      return view ('formulaires.absenceform',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      request()->validate([
         'date'=>['required','date'],
         'nom' => ['required']
       ]);

    $nom = explode(" ",request("nom"));

    $ideffectif =  \App\Effectif::where('Nom',$nom[0])
                                    ->where('Prenom',$nom[1])
                                     ->value('id');

    if( Absence::where('IDEffectif',$ideffectif)
               ->where('Dateabsence',request('date'))->get() != "[]" ){
          return "<h2>Cette absence est déja enregistrée </h2>";
       }

   else  {

       Absence::create([
         'IDEffectif' => $ideffectif,
         'DateAbsence'=>request("date"),
         'Motif'=>request("motif"),
       ]);

      return '<h2>Nous avons bien recu vos informations:'.
        request('nom')." ".
        request('date')." ".request('motif').'</h2>';
    }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Absence  $absence
     * @return \Illuminate\Http\Response
     */
    public function show(Absence $absence)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Absence  $absence
     * @return \Illuminate\Http\Response
     */
    public function edit(Absence $absence)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Absence  $absence
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Absence $absence)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Absence  $absence
     * @return \Illuminate\Http\Response
     */
    public function destroy(Absence $absence)
    {
        //
    }
}
