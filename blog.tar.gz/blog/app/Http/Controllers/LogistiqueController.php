<?php

namespace App\Http\Controllers;

use App\Effectif;
use App\Logistique;
use Illuminate\Http\Request;

class LogistiqueController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $effectifs =  \App\Effectif::all();
      $matchs =  \App\Match::all();

      return view ('formulaires.logistiqueform',
                    ['effectifs'=>$effectifs,
                      'matchs'=>$matchs]);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

      request()->validate([
        'nom' => ['required'],
	      'date'=>['required','date']
	     ]);

    $nom = explode(" ",request("nom"));

     $idmatch = \App\Match::where('Date',request("date"))
                             ->value('id');

     $ideffectif = \App\Effectif::where('Nom',$nom[0])
                                  ->where('Prenom',$nom[1])
                                   ->value('id');



   if( Logistique::where('IDEffectif',$ideffectif)
                  ->where('IDMatch',$idmatch)->get() != "[]" ){
             return "<h2>".request("nom")." a déja une tâche </h2>";
          }

   else {

	     Logistique::create([
	      'IDEffectif' => $ideffectif,
	      'IDMatch'=> $idmatch,
	      'Tache'=>request("tache"),
	     ]);

      	return '<h2>Nous avons bien recu vos informations:'
          .request('nom')." "
          .request('date')." ".request('tache')."</h2>";
     }

   }

    /**
     * Display the specified resource.
     *
     * @param  \App\Logistique  $logistique
     * @return \Illuminate\Http\Response
     */
    public function show(Logistique $logistique)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Logistique  $logistique
     * @return \Illuminate\Http\Response
     */
    public function edit(Logistique $logistique)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Logistique  $logistique
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Logistique $logistique)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Logistique  $logistique
     * @return \Illuminate\Http\Response
     */
    public function destroy(Logistique $logistique)
    {
        //
    }
}
