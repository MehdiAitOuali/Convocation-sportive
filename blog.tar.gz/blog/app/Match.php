<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Match extends Model
{
  protected $table = 'MATCHS';

  protected $fillable = [
      'IDEquipe', 'DateMatch','ClubAdverse',
      'LocaliteClubAdverse', 'EquipeAdverse',
      'Terrain', 'Competition','Deplacement',
      'Site'
  ];

 public $timestamps = false;
}
