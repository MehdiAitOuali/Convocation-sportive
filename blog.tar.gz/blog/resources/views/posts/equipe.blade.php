
<table class="table table-dark">

<?php foreach ($equipes as $equipe): ?>

<tr><td> {{$equipe->NomEquipe}} </td><td> {{$equipe->IDCategorie}} </td> </tr>

<?php endforeach; ?>

</table>
