<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
<style>    
</style>
  </head>
  <body>


<table width="1000">
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td>
      <a href="/"><h4>Acceuil</h4></a>
    </td>
  </tr>
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>


  <tr>
    <td><a href="/absence/create"><h4>Ajouter une Absence</h4></a></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><a href="/logistique/create"><h4>Ajouter une tâche</h4></a></td>
    <td></td>
    <td></td>
    <td></td>
 </tr>

</table>



<?php echo $__env->yieldContent('contenu'); ?>

<p>
  </body>
</html>
