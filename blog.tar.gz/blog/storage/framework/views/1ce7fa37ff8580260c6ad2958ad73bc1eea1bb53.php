
<table class="table table-dark">



<?php foreach ($equipes as $equipe): ?>

<tr><td><?php echo e($equipe->NomEquipe); ?> </td>
    <td>
      <?php echo e($categories->find($equipe->IDCategorie)->NomCategorie); ?>

    </td> </tr>

<?php endforeach; ?>

</table>
