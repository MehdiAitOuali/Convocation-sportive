<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToCONVOCATIONTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('CONVOCATION', function(Blueprint $table)
		{
			$table->foreign('IDArbitrage', 'CONVOCATION_ibfk_1')->references('id')->on('ARBITRAGE')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('CONVOCATION', function(Blueprint $table)
		{
			$table->dropForeign('CONVOCATION_ibfk_1');
		});
	}

}
