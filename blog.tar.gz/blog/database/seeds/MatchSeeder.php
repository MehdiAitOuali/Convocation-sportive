<?php

use Illuminate\Database\Seeder;

class MatchSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::statement('SET FOREIGN_KEY_CHECKS=0');
      DB::table('MATCHS')->truncate();
      DB::statement('SET FOREIGN_KEY_CHECKS=1');

      $fichier = fopen('/var/www/html/blog/csv/matchs.csv','r');

       $i=false;

       while($data = fgetcsv($fichier,1000,",")){
         if($i){

           $heure = explode("H",$data[7]);
           $heurematch = $heure[0].":".$heure[1].":00";

           DB::table('MATCHS')->insert([
           'IDEquipe' => DB::table('EQUIPE')->where('NomEquipe',$data[2])
                        ->value('id'),
           'Date' => $data[6],
           'Heure' => $heurematch,
           'ClubAdverse' => $data[3],
           'LocaliteClubAdverse' => $data[4],
           'EquipeAdverse' => $data[5],
           'Terrain' => $data[9],
           'Competition' => $data[1],
           'Deplacement' => $data[8],
           'Site' => $data[10]
         ]);
         }
         else {
           $i=true;
         }

       }


    }
}
